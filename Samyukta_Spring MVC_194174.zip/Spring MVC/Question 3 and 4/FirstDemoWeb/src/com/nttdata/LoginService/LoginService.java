package com.nttdata.LoginService;

import org.springframework.stereotype.Service;

@Service
public class LoginService {
	public boolean isUserValid(String user,String pass)
	{
		if(user.equals("ntt") && pass.equals("ntt"))
		return true;
		
		return false;
		
	}

}
