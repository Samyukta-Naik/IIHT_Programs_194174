package com.nttdata.Vehicle;


public class Bike extends Vehicle {
	private String bikeNum;
	private String bikeName;
	private double price;
	private String color;
	
	public String getBikeNum() {
		return bikeNum;
	}

	public void setBikeNum(String bikeNum) {
		this.bikeNum = bikeNum;
	}

	public String getBikeName() {
		return bikeName;
	}

	public void setBikeName(String bikeName) {
		this.bikeName = bikeName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	
	public Bike(String bikeNum, String bikeName, double price, String color) {
		super();
		this.bikeNum = bikeNum;
		this.bikeName = bikeName;
		this.price = price;
		this.color = color;
	}

	void display()
	{
		System.out.println("BikeNumber\tBikeName\tPrice\tCarColor");
		System.out.println(bikeNum+"\t"+bikeName+"\t"+price+"\t"+color);
	}

}
