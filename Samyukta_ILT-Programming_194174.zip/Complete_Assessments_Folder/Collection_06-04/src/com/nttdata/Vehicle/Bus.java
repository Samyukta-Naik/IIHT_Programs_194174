package com.nttdata.Vehicle;

public class Bus extends Vehicle {
	private String busNum;
	private String busName;
	private double price;
	private String color;
	
	public String getBusNum() {
		return busNum;
	}
	public void setBusNum(String busNum) {
		this.busNum = busNum;
	}
	public String getBusName() {
		return busName;
	}
	public void setBusName(String busName) {
		this.busName = busName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	

	public Bus(String busNum, String busName, double price, String color) {
		super();
		this.busNum = busNum;
		this.busName = busName;
		this.price = price;
		this.color = color;
	}
	void display()
	{
		System.out.println("BusNumber\tBusName\tPrice\tCarColor");
		System.out.println(busNum+"\t"+busName+"\t"+price+"\t"+color);
	}

}