package com.nttdata.Vehicle;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) {
		int i;
		
		Vehicle v=new Vehicle();
		v.display();
		do{
		System.out.println();
		System.out.println("Enter 1:Car 2.Bike 3.Bus 4:Exit");
		Scanner sc=new Scanner(System.in);
	
		 i=sc.nextInt();
		
		switch(i)
		{
		case 1:
		int is;
		Vehicle vc = new Car("KA451122","Innova",700000,"White");
		vc.display();
		do{
		System.out.println();
		System.out.println("Enter 1:start 2.stop 3.Exit");
		is=sc.nextInt();
		switch(is)
		{
		case 1:
			Engine e=new Engine();
			e.start();
			break;
			
		case 2:
			Engine eng=new Engine();
			eng.stop();
			break;
		case 3:
			System.out.println("=================================================================================");
			break;

		}
		}while(is!=3);
		break;
		
		case 2:
		
		Vehicle vb = new Bike("KA454422","KTM",100000,"Black");
		vb.display();
		System.out.println();
		System.out.println("Enter 1:start 2.stop 3.Exit");
		int ib=sc.nextInt();
		switch(ib)
		{
		case 1:
			Engine e=new Engine();
			e.start();
			break;
			
		case 2:
			Engine eng=new Engine();
			eng.stop();
			break;
		case 3:
			System.out.println("=================================================================================");
			break;

		}
		break;
		
		case 3:
			
			Vehicle vbs = new Bike("KA87593","KSRTC",400000,"Blue");
			vbs.display();
			System.out.println();
			System.out.println("Enter 1:start 2.stop 3.Exit");
			int ibs=sc.nextInt();
			switch(ibs)
			{
			case 1:
				Engine e=new Engine();
				e.start();
				break;
				
			case 2:
				Engine eng=new Engine();
				eng.stop();
				break;
			case 3:
				System.out.println("=================================================================================");
				break;
			}
			break;
			
	}

		}while(i!=4);

}
}