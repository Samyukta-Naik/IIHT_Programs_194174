package com.nttdata.Vehicle;

public class Car extends Vehicle {
	private String carNum;
	private String carName;
	private double price;
	private String color;
	public String getCarNum() {
		return carNum;
	}
	public void setCarNum(String carNum) {
		this.carNum = carNum;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public Car(String carNum, String carName, double price, String color) {
		super();
		this.carNum = carNum;
		this.carName = carName;
		this.price = price;
		this.color = color;
	}
	void display()
	{
		System.out.println("CarNumber\tCarName\tPrice\tCarColor");
		System.out.println(carNum+"\t"+carName+"\t"+price+"\t"+color);
	}

}
