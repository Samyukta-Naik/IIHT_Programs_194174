package com.nttdata.Vehicle;

public class Vehicle {
	
	void display(){
	System.out.println("Welcome to Vehicle World");
}
}
