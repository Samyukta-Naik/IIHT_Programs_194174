package com.nttdata.Collection;

public class Employee implements Comparable <Employee> {
	private int employeeId;
	private String employeeName;
	private String employeeAddress;
	private double employeeSalary;
	private String employeeGrade;
	private double phoneNumber;
	private String employeeEmail;
	
	public Employee(int employeeId, String employeeName, String employeeAddress, double employeeSalary,
			String employeeGrade, double phoneNumber, String employeeEmail) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeeSalary = employeeSalary;
		this.employeeGrade = employeeGrade;
		this.phoneNumber = phoneNumber;
		this.employeeEmail = employeeEmail;
	}

	@Override
	public int compareTo(Employee e) {
		
		if(employeeId>e.employeeId){  
		        return 1;  
		    }
		else if(employeeId<e.employeeId){  
		        return -1;  
		    }
		else{  
		    	return 0;  
		    }  
	}

	@Override
	public String toString() {
		/*return "employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", employeeSalary=" + employeeSalary + ", employeeGrade=" + employeeGrade
				+ ", phoneNumber=" + phoneNumber + ", employeeEmail=" + employeeEmail ;*/
		return employeeId + "\t\t"+ employeeName + "\t\t"+ employeeAddress + "\t\t"+ employeeSalary + "\t\t"+ employeeGrade
		+ "\t\t"+ phoneNumber + "\t" + employeeEmail ;
	}
	
	
	

}