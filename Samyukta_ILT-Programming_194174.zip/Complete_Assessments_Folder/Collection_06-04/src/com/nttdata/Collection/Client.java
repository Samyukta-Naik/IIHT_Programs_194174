package com.nttdata.Collection;

import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Client {

	public static void main(String[] args) {
		
		Set<Employee> set=new TreeSet<Employee>();
		
		set.add(new Employee(151,"Ram","Delhi",25000,"Grade 5",12345678,"ram@gmail.com"));
		set.add(new Employee(182,"Sham","Mysore",35000,"Grade 7",23456787,"sham@gmail.com"));
		set.add(new Employee(145,"Harry","Goa",15000,"Grade 5",987654345,"harry@gmail.com"));
		set.add(new Employee(128,"Rosy","Chennai",55000,"Grade 6",758496123,"rosy@gmail.com"));
		
		Iterator<Employee> itr=set.iterator();
		System.out.println("Employee Detals are:");
		System.out.println("EmployeeId\tEmployeeName\tEmployeeAddress\tEmployeeSalary\tEmployeeGrade\tPhoneNumber\tEmployeeEmail");
		while(itr.hasNext()){
			
			System.out.println(itr.next());
		}

		
		
	}


}


