package com.nttdata.Dao;

import java.util.List;

import com.nttdata.Model.Employee;

public interface EmployeeDao {

	Employee getEmployeeById(int id);
	Employee createEmployee();
	Employee deleteEmployee(int id);
	List<Employee> list();
	Employee searchEmployeeByName(String name);
}
