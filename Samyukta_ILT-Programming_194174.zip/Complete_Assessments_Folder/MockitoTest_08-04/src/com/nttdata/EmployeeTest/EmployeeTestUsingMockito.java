package com.nttdata.EmployeeTest;

import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.mockito.Mockito;

import com.nttdata.Dao.EmployeeDao;
import com.nttdata.Model.Employee;

public class EmployeeTestUsingMockito {

	EmployeeDao employeeDao=Mockito.mock(EmployeeDao.class);

	@Test
	public void testgetEmployeeById() 
	{
		Employee employee=new Employee(20,"Ram","Goa",25000);
		Mockito.when(employeeDao.getEmployeeById(employee.getEmployeeId())).thenReturn(employee);
	}
	
	@Test
	public void testCreateEmployee()
	{
		Employee employee=new Employee(95,"Raj","Bangalore",25500);
		Mockito.when(employeeDao.createEmployee()).thenReturn(employee);
	}
	
	@Test
	public void testdeleteEmployee()
	{
		Employee employee=new Employee(45,"Sham","Chennai",26000);
		Mockito.when(employeeDao.deleteEmployee(employee.getEmployeeId())).thenReturn(employee);
	}
	
	@Test
	public void testListEmployee()
	{
		List <Employee>list=new ArrayList<Employee>();
		list.add(new Employee(37,"Ram","Goa",30000));
		list.add(new Employee(16,"Rosy","Bangalore",32000));
		list.add(new Employee(42,"Prince","Mangalore",35000));
		list.add(new Employee(10,"John","Mysore",42300));
		
		Mockito.when(employeeDao.list()).thenReturn(list);
		
	}
	@Test
	public void testsearchEmployeeByName()
	{
		Employee employee=new Employee(45,"Sham","Chennai",26000);
		Mockito.when(employeeDao.searchEmployeeByName(employee.getEmployeeName())).thenReturn(employee);
		
	}

}
