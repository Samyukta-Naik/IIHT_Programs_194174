package com.nttdata;

import java.util.Scanner;

public class Client {

	public static void main(String[] args) throws insufficientamount{
		
		user u1=null;		
		user u2=null;
		int a;
		do{
		System.out.println();
		System.out.println("*****************************Welcome to bank Application*****************************");
		System.out.println("Press:  1) Create Account \n\t2) Transerfunds \n\t3) Quit");
		Scanner sc=new Scanner(System.in);
		a=sc.nextInt();
		
		switch(a)
		{
			case 1:
					System.out.println("Press:   1) Create account \n\t 2) Reapet account creation \n\t 3) Quit");
				int ch=sc.nextInt();
				
				switch(ch)
				{
				
				case 1:	
					u1=new user();
					Account aa=new Account();
					System.out.println("Enter Account Id");
					int id=sc.nextInt();
					aa.setAccid(id);
					System.out.println("Enter Amount");
					int amt=sc.nextInt();
					aa.setAmount(amt);
										
					System.out.println("Enter User Name");
					String name=sc.next();
					u1.setUsername(name);
					u1.setA(aa);			
					
					System.out.println("Account Created Successfully!!!!");
					System.out.println("Your Account Details are");
					System.out.println("Name \t Account Id \t Amount");
					System.out.println(u1.getUsername()+" \t "+u1.getA().getAccid()+" \t\t "+u1.getA().getAmount());
					break;
					
				case 2:
					u2=new user();
					Account ab=new Account();
					System.out.println("Enter Account Id");
					int id2=sc.nextInt();
					ab.setAccid(id2);
					System.out.println("Enter Amount");
					int amt2=sc.nextInt();
					ab.setAmount(amt2);
					
					System.out.println("Enter User Name");
					String name2=sc.next();
					u2.setUsername(name2);
					u2.setA(ab);
					System.out.println("Account Created Successfully!!!!");
					System.out.println("Your Account Details are");
					System.out.println("Name \t Account Id \t Amount");
					System.out.println(u2.getUsername()+" \t "+u2.getA().getAccid()+" \t\t "+u2.getA().getAmount());
					break;
					
				case 3:
					System.out.println("==========================================================================================");
					break;
				}
				break;
				
		case 2: 
				System.out.println("Press:  1) Transfer Amount from user 1 to user2  \n\t2) Transfer Amount from user2 to user 1 \n\t3) Quit");
				int ch1=sc.nextInt();
				switch(ch1)
				{	
				case 1:	bank b=new bank();
					System.out.println("Enter Amount to Transfer");
					double amount=sc.nextDouble();
					try
					{
						b.transferfunds(u1, u2, amount);
					}
					catch(insufficientamount e)
					{
						e.printStackTrace();
					}
					System.out.println("Amountt Transfered Successfully!!!!");
					System.out.println("after transaction Customer Detais Are");
					System.out.println("Name \t Account Id \t Amount");
					System.out.println(u1.getUsername()+" \t "+u1.getA().getAccid()+"\t\t  "+u1.getA().getAmount());
					System.out.println(u2.getUsername()+" \t "+u2.getA().getAccid()+" \t\t "+u2.getA().getAmount());
					break;
					
				case 2:
					bank b1=new bank();
					System.out.println("Enter Amount to Transfer");
					double amount1=sc.nextDouble();
					try
					{
					b1.transferfunds(u2, u1, amount1);
					}catch(insufficientamount e)
					{
						e.printStackTrace();
					}
					System.out.println("Amountt Transfered Successfully!!!!");
					System.out.println("after transaction Customer Detais Are");
					System.out.println("Name \t Account Id \t Amount");
					System.out.println(u1.getUsername()+" \t "+u1.getA().getAccid()+"\t\t  "+u1.getA().getAmount());
					System.out.println(u2.getUsername()+" \t "+u2.getA().getAccid()+" \t\t "+u2.getA().getAmount());
					break;
					
				case 3:
					System.out.println("==========================================================================================");
					break;
		
				}
				break;
			}
		}while(a!=3);
	}
}