package com.nttdata;

public class insufficientamount extends Exception {

	public insufficientamount(String message)
	{
		System.out.println("exception");
	}
	
	
	
}
