package com.nttdata;

public class user {
private String username;
private Account a;
public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public Account getA() {
	return a;
}
public void setA(Account a) {
	this.a = a;
}
}
