package com.nttdata;


public class bank {
void transferfunds(user u1,user u2,double amount) throws insufficientamount
{
	if(u1.getA().getAmount()<amount)
	{
		throw new insufficientamount("you have no ammount");
	}
	else
	{
	double u1amt=	u1.getA().getAmount();
	double	amt=u1amt-amount;
	u1.getA().setAmount(amt);
	double u2amt=	u2.getA().getAmount();
	double	amt2=u2amt+amount;
	u2.getA().setAmount(amt2);
	}
}
}
