package com.nttdata;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Client {

	public static void main(String[] args) {
		
		List<Employee> emp=new ArrayList <Employee>();
		
		emp.add(new Employee(101,"Ram",35000));
		emp.add(new Employee(105,"emma",1000));
		emp.add(new Employee(102,"tom",25000));
		emp.add(new Employee(106,"amar",15000));
		emp.add(new Employee(102,"Sham",5000));
		
		List<Employee> sal1=emp.stream().filter(p->p.getSal()>10000).collect(Collectors.toList());
		System.out.println("Employees getting Salary more than 10000 are: "+ sal1);
		
		long cnt=emp.stream().filter(p->p.getSal()>10000).map(p->p.getSal()).collect(Collectors.counting());
		System.out.println("\n Total no. of employees getting Salary more than 10000 are:\n"+cnt);

	}

}
