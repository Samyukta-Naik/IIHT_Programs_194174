package com.nttdata;

public class Employee {
	private Integer empId;
	private String naame;
	private double sal;
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getNaame() {
		return naame;
	}
	public void setNaame(String naame) {
		this.naame = naame;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	public Employee(Integer empId, String naame, double sal) {
		super();
		this.empId = empId;
		this.naame = naame;
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "\n Employee [empId=" + empId + ", naame=" + naame + ", sal=" + sal + "]";
	}
	

}
