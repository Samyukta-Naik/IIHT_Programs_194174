
select passname from passenger where passname like "_e%";

select passname from passenger where passdob= (select max(passdob) max from passenger);

SELECT PASSNAME,PASSDOB,ROUND((DATEDIFF(NOW(),PASSDOB)/365),2) AGE FROM PASSENGER;
 
SELECT COUNT(*) NO_OF_FLIGHTS FROM FLIGHT WHERE FLIGHTSOURCE="KOL";

SELECT FLIGHTSOURCE FROM 
 (SELECT FLIGHTSOURCE,COUNT(*) C1 FROM FLIGHT GROUP BY  FLIGHTSOURCE)a1 INNER JOIN 
 (SELECT FLIGHTDEST,COUNT(*) C2 FROM FLIGHT GROUP BY FLIGHTDEST)a2 ON a1.C1=a2.C2 AND  
 a1.FLIGHTSOURCE=a2.FLIGHTDEST;

SELECT FLIGHTSOURCE FROM FLIGHT where FLIGHTSOURCE  NOT IN (SELECT FLIGHTDEST FROM FLIGHT);
 
 SELECT FLIGHTDATE FROM FLIGHT WHERE FLIGHTID=1 OR FLIGHTID=4;

SELECT FLIGHTID,COUNT(bd.PASSID) PASSCOUNT FROM BOOKING_DETAILS bd INNER
 JOIN BOOKING b ON b.BOOKINGID=bd.BOOKINGID GROUP BY FLIGHTID;

SELECT PASSNAME,PASSDOB FROM PASSENGER where (ROUND((DATEDIFF(NOW(),PASSDOB)/365)))>=60;

SELECT BOOKINGID FROM BOOKING_DETAILS GROUP BY BOOKINGID HAVING COUNT(PASSID)=
 ( SELECT MAX(total) FROM ( SELECT BOOKINGID,COUNT(PASSID) total FROM BOOKING_DETAILS GROUP BY BOOKINGID ) new);


SELECT B.BOOKINGID,F.TICKETCOST TOTAL_FARE FROM BOOKING B INNER JOIN FLIGHT F ON B.FLIGHTID=F.FLIGHTID;

 select b.bookingid,case
                       when round(datediff(curdate(),p.passdob)/365)>60 then f.ticketcost/2
                       else f.ticketcost
                   end as 'Total_Fare'
from booking b,flight f,booking_details bd,passenger p
where b.bookingid=bd.bookingid and b.flightid=f.flightid and bd.passid=p.passid;

 select flightdest from flight 
group by flightdest 
having count(*)=(select max(fli) from (select count(*) fli 
					from flight 
                       group by flightdest)high);

 
SELECT PASSNAME FROM PASSENGER WHERE PASSID IN 
 (SELECT PASSID FROM BOOKING_DETAILS GROUP BY PASSID HAVING COUNT(BOOKINGID)>1);


 select flightid,count(*) NO_OF_BOOKINGS from booking group by flightid;


 select p.passname from passenger p,booking b,flight f,booking_details d
 where b.flightid="1" and f.flightdate=b.bookdate and d.passid=p.passid and b.bookingid=d.bookingid;


 select flightid from flight where flightdest=flightsource;


 select concat("Ticket No:",bookingid," Flight id: ",fl.flightid," Total Passengers: ",count(bookingid)," Total Fare:",count(bookingid)*ticketcost) booking_details
 from booking 
 inner join
 flight fl
 on 
 booking.flightid=fl.flightid
 group by 
 fl.flightid; 


 select flightid,flightdate,CASE 
     WHEN FLIGHTID=2 THEN adddate(FLIGHTDATE,interval 4 hour)
     ELSE FLIGHTDATE
     END AS ' NEW DATE'
     FROM FLIGHT;


 select passname,passdob from passenger order by passdob;