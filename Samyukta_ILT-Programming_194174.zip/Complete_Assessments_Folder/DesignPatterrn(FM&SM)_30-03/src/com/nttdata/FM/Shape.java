package com.nttdata.FM;

public interface Shape {
	   void draw();
	}
	