package com.nttdata.OpenClosed;

public class AreaCalculator {

	public double calculateShapeArea(Shape shape)
	{
		return shape.calculateArea();
	}
}
