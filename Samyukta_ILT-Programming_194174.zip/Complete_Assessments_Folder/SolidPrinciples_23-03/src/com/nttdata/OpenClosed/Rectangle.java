package com.nttdata.OpenClosed;

public class Rectangle implements Shape
{
	double length;
	double width;
	public double calculateArea()
	{
		return length * width;
	}
}