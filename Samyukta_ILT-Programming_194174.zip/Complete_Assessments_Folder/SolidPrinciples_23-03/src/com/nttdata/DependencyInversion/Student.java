package com.nttdata.DependencyInversion;

public class Student {
	
	  private Address address;
	   public Student()
	  {
	    address = new Address();
	   }
}
/*It allows a programmer to remove hardcoded dependencies so that the application becomes loosely coupled and extendable.
Student class requires an Address object and it is responsible for initializing and using the Address object. If Address class is changed in future
then we have to make changes in Student class also. This makes the tight coupling between Student and Address objects. We can resolve this problem 
using the dependency inversion design pattern. i.e. Address object will be implemented independently and will be provided to Student
when Student is instantiated by using constructor-based or setter-based dependency inversion.*/