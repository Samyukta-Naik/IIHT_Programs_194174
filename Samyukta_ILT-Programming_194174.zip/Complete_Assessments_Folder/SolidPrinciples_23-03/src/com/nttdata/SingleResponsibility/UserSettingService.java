package com.nttdata.SingleResponsibility;

public class UserSettingService
{
   public void changeEmail(User user)
  {
    if(SecurityService.checkAccess(user))
   {
		//Grant option to change
   }
 }
 
}
 
