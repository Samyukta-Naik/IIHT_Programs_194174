package com.nttdata.SingleResponsibility;

public class User {
	
	//User Details
}
