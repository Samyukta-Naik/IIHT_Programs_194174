package com.nttdata.SingleResponsibility;

public class SecurityService
{
public static boolean checkAccess(User user)
{

		//check the access.
	return true;
}
}