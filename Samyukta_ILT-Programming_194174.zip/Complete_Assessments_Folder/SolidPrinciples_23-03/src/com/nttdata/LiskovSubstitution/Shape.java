package com.nttdata.LiskovSubstitution;

public interface Shape {
	
	//method

}
