package com.nttdata.LiskovSubstitution;

public interface SolidShape {
	
	void volume();

}
