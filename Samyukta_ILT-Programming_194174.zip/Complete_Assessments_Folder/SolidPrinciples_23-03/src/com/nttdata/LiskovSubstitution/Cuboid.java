package com.nttdata.LiskovSubstitution;

public class Cuboid implements SolidShape ,Shape
{
	
	
	public void area() 
	{
		// TODO Auto-generated method stub
	}
	
	private double length;
	private  double breadth;
	private  double height;
	@Override
	public void volume()
	{
		// TODO Auto-generated method stub
		
	}
}
