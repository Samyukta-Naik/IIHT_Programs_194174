package com.nttdata.LiskovSubstitution;

public class Cube implements SolidShape ,Shape
{
	

	public void area() 
	{
		// TODO Auto-generated method stub
	}
	
	private double side;
	@Override
	public void volume()
	{
		// TODO Auto-generated method stub
		
	}
}