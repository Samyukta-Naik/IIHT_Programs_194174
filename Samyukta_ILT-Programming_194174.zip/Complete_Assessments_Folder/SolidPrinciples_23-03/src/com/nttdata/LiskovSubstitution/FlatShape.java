package com.nttdata.LiskovSubstitution;

public interface FlatShape {

	void area();
	
}
